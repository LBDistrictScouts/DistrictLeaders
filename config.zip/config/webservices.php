<?php

return [
    'Webservices' => [
        'git_hub' => [
            'className' => 'Muffin\Webservice\Connection',
            'service' => 'CvoTechnologies/GitHub.GitHub',
        ],
    ]
];
