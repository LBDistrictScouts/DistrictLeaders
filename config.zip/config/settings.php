<?php
/**
 * Created by PhpStorm.
 * User: jacob
 * Date: 2019-01-03
 * Time: 20:55
 */

return [

    'Passwordable' => [
        'field' => 'password',
        'confirm' => true,
        'require' => true,
    ]
];
