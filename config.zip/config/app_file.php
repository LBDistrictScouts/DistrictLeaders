<?php

use \Aws\S3\S3Client;

$client = S3Client::factory([
    'credentials' => [
        'key' => 'AKIAJLIJWU6TGWGVHHMA',
        'secret' => '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',
    ],
    'region' => 'eu-west-1',
    'version' => 'latest',
]);

return [
    'Filesystem' => [
        'default' => [
            'adapter' => '\League\Flysystem\AwsS3v3\AwsS3Adapter',
            'adapterArguments' => [
                $client,
                'lbdscouts-leaders-dev',
            ]
        ],
        'other' => [
            'adapter' => 'Local',
            'adapterArguments' => [ WWW_ROOT . 'files' ],
        ]
    ],

    'CloudConvert' => [
        'api_key' => '1rg2DchVfk71Rc4g6zB9oI0UGecr2Cy4MTZR8WWxaCh93PSSEtb0Wko6HAzvvs6D',
        's3' => [
            'key' => '__INSERT_CC_S3_IAM_KEY__',
            'secret' => '__INSERT_CC_S3_IAM_SECRET__',
            'region' => 'eu-west-1',
            'bucket' => 'lbdscouts-leaders-dev'
        ]
    ],
];
